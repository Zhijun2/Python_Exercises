temperature = int(input('输入温度： '))

if temperature >= 40:
  print('太热了')
elif temperature >= 35:
  print('很热')
elif temperature >= 30:
  print('热')
else:
  print('不热')
