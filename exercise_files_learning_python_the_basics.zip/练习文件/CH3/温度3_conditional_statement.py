temperature = int(input('输入温度： '))

print('太热了' if temperature >= 40 else  '很热' if temperature >= 35 else '热')
