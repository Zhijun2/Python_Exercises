temperature = int(input('输入温度： '))

if 30 <= temperature < 35:
  print('热')
elif 35 <= temperature < 40:
  print('很热')
elif temperature >= 45:
  print('太热了')   
