# 年分可以被4整除, 为闰年, 除非是世纪年
# 世纪年是平年, 除非可被400整除

year = int(input('输入年份: '))

if (year % 4) == 0:
    if (year % 100) == 0:
        if (year % 400) == 0:
            print(year, '是闰年')
        else:
            print(year, '是平年')
    else:
        print(year, '是闰年')
else:
    print(year, '是平年')
