age = int(input('输入你的年龄： '))
print('你到了适婚年龄') if age >= 21 else print('还不可以结婚')
