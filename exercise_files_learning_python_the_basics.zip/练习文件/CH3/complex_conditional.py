x = int(input('输入一个整数： '))

if x >= 0 and x <=10:
    print('你输入的数介于0和10')
else:
    print('你输入的数不介于0和10')
