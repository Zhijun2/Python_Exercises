temperature = int(input('输入温度： '))
if temperature >= 30:
  print('热')
elif temperature >= 35:
  print('很热')
elif temperature >= 40:
  print('太热了')
else:
  print('不热')
