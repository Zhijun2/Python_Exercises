isRain = input('下雨吗？Y/N ')

if isRain == 'Y':
    print('带雨伞出门')
else:
    print('去打球')
