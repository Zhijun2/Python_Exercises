isGreedy = False
if not isGreedy:
    print('你不会上当')
