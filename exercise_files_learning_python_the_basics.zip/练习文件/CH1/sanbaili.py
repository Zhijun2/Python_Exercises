print('一拜')
print('二拜')
print('三拜')
