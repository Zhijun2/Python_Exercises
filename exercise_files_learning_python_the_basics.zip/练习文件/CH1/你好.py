甲 = '你好'
print(甲)
