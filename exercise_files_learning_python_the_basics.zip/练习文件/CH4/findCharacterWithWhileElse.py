密码 = 'secret'
count = 0

password = input('输入密码： ')
count += 1

while password != 密码:
    print('密码错误. 还剩', 3-count, '次')
    password = input('请再输入密码： ')
    count += 1

    if count >= 3 and password != 密码:
        print('密码输入尝试超过三次')
        break
else:
    print('密码正确. 成功登陆')
