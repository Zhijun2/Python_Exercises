# print the first 5 prime numbers from 1 to 50
count = 0
for i in range(1,50):
    for j in range(2,i):# check for factors
        if i%j == 0:    # if it is divisible by any number from 2 to i, it is NOT a prime
            break       # break out the current range and move to check the next number
    else:               # it is a prime
        if count < 5:
            print(i)
            count += 1
        else:
            break
 

