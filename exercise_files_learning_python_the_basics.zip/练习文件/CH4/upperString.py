for character in 'Alvin Yu':
    if character.islower():
        print(character.upper(), sep = '', end ='')
    else:
        print(character, end = '')
print()
