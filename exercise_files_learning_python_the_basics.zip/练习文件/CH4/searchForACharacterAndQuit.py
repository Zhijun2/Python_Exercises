要找到字 = input('输入要找的字： ')
找到了 = False

text = '读书破万卷，下笔如有神'

for word in text:
    if word == 要找到字:
        找到了 = True
        print('找到了')
        break

if not 找到了:
    print('没有找到这个字')
