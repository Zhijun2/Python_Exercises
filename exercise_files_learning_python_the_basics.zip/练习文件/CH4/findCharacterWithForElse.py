要找到字 = input('输入要找的字： ')
text = '读书破万卷，下笔如有神'

for word in text:
    if word == 要找到字:
        print('找到了')
        break;
else:
    print('没有找到')
