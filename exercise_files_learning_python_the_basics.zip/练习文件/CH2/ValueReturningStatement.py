print(int(input("enter a number ")))
