age = input('你几岁？ ')
print('明年你', (lambda n: int(n)+1)(age))
