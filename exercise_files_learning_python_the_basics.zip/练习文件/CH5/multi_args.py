def multi_add(*args):
       result = 0
       for x in args:
           result = result + x
       return result

sum = multi_add(1,2,3,4,5,6,7,8,9,10)
print(sum)
