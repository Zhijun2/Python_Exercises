def power(num, n = 2):
    result = 1
    for i in range(n):
        result = result * num
    print(result)
power(2)
power(2, 3)
power(2, 4)
