TAX_RATE = 0.1

def computeTax(salary):
    tax = salary* TAX_RATE
    print("应缴税： ", tax)

computeTax(10000)
