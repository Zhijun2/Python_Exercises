with open('静夜思.txt', 'r', encoding='utf-8') as infile:
    for line in infile :
        print(line)
    
