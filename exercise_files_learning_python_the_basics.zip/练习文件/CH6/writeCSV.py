import csv

count = 1
with open('sample.csv', 'w') as output:
    write = csv.writer(output)
    while count < 10:
        write.writerow((lambda x, y, z: x + y + z)('第', str(count), '行'))
        count += 1
