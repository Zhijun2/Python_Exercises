file = open('静夜思.txt', 'r', encoding='utf-8')
contents = file.readlines()

for text in contents :
    print(text)
file.close()
