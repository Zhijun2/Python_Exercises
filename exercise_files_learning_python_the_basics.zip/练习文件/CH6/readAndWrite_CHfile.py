infile = open('静夜思.txt', 'r', encoding='utf-8')
outfile = open('静夜思_out.txt', 'w', encoding='utf-8')
line_num = 1

for line in infile :
    outfile.write(str(line_num) + ' ' + line)
    line_num += 1

infile.close()
outfile.close()
