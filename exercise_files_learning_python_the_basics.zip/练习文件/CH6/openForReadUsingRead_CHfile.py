file = open('静夜思.txt', 'r', encoding='utf-8')
contents = file.read()
print(contents)
file.close()
