file1 = open('poem.txt', 'r')
contents = file1.readlines()
for text in contents :
    print(text)
file1.close()
