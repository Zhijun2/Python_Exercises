import pickle

#infile = open("静夜思.txt", "rb")
outfile = open("静夜思out.bin", "wb")


with open("静夜思.txt", "rb") as file:
    pickle.dump(file, outfile)
