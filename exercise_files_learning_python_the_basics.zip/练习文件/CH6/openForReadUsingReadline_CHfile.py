file = open('静夜思.txt', 'r', encoding='utf-8')

while True:
    line = file.readline()
    if not line:
        break
    print(line)
file.close()
