import csv

with open('douban_top20utf8.csv', encoding='utf-8') as inCVSfile:
    csvreader = csv.reader(inCVSfile, delimiter=',')
    for row in csvreader:
        print('书名: ' + row[0])
        print('作者: ' + row[1])
        print('出版社：' + row[2])
        print('出版日期: ' + row[3])
        print('定价: ' + row[4])
        print('豆瓣评分： ' + row[3])
        print()

